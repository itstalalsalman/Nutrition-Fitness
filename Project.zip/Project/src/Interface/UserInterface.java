package Interface;

public interface UserInterface {

	public double calculateBMI();
	
}
