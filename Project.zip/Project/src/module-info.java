/**
 * 
 */
/**
 * @author Talal Salman
 *
 */
module Project {
	requires java.desktop;
}